package it.volta.ts.ulivisamuel.cifrdecifrRSA;

public class Main {

	public static void main(String[] args)
	{	
		new Console().esegui();
	}
}
