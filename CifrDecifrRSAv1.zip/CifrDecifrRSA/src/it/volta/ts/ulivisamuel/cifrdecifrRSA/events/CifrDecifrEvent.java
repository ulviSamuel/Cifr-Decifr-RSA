package it.volta.ts.ulivisamuel.cifrdecifrRSA.events;

import java.util.EventObject;

public class CifrDecifrEvent extends EventObject
{
	public CifrDecifrEvent(Object source) 
	{
		super(source);
	}
}
